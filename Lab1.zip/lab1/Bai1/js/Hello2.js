alert("Welcome to Polytechnic");
document.write("<h1> The first JavaScript App<h1/>");
