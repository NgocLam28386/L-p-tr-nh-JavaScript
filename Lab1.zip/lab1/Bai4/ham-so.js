function kiem_tra(x) {
    if (x % 2 == 0) {
        alert("x là số chẵn: " + x);
    } else {
        alert("x là số lẻ: " + x);
    }
}